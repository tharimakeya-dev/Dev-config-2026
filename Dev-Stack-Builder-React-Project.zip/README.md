# Dev Stack Builder

A responsive React website for exploring modern development technologies and building a personal technology stack.

## Technologies
- React.js + Vite
- JavaScript (ES6+)
- CSS responsive layout
- React-Toastify
- JSON data

## Features
1. Technology cards loaded from a local JSON file.
2. Add/remove technologies with duplicate protection and toast notifications.
3. Responsive navbar, hero, technology grid, stack sidebar, projects, about, contact and footer.

## React Questions

### 1. What is JSX, and why is it used in React?
JSX is a syntax that lets us write HTML-like UI inside JavaScript. React uses it to make components easier to read and build.

### 2. What is the difference between props and state?
Props are data passed into a component by its parent. State is data managed inside a component that can change over time.

### 3. What does the useState hook do, and where did you use it?
`useState` stores changing data in a component. This project uses it for the loaded technologies, selected stack and mobile menu state.

### 4. What does useEffect do, and why did you need it?
`useEffect` runs side effects after rendering. It is used here to fetch the technology JSON data when the app loads.

### 5. Why does every item in a .map() list need a unique key prop?
React uses the key to identify which list item changed, was removed or was added. A stable unique key helps React update the UI correctly.

### 6. What is conditional rendering?
Conditional rendering means showing different UI based on a condition. Here, the stack shows an empty-state message when `stack.length === 0`, otherwise it shows selected technologies.

### 7. How do you pass data from parent to child, and how does a child send something back?
A parent passes data through props. A child can send information back by calling a callback function that the parent passes as a prop.

## Run locally

```bash
npm install
npm run dev
```

Then open the local Vite URL in your browser.
