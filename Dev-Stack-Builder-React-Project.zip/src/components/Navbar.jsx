import React, { useState } from 'react';
import Logo from './Logo';

const links = [
  ['Home', '#home'],
  ['Technologies', '#technologies'],
  ['Projects', '#projects'],
  ['About', '#about'],
  ['Contact', '#contact']
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  return (
    <header className="navbar-wrap">
      <nav className="navbar container">
        <button className="hamburger" aria-label="Open menu" onClick={() => setOpen(!open)}>
          <span></span><span></span><span></span>
        </button>
        <Logo />
        <div className={`nav-links ${open ? 'nav-links--open' : ''}`}>
          {links.map(([label, href]) => (
            <a key={label} href={href} onClick={() => setOpen(false)}>{label}</a>
          ))}
        </div>
        <div className="nav-actions">
          <button className="btn btn-ghost">Sign In</button>
          <button className="btn btn-gradient">Sign Up</button>
        </div>
      </nav>
    </header>
  );
}