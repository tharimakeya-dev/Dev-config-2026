import React from 'react';

export default function TechnologyCard({ tech, added, onAdd }) {
  return (
    <article className={`tech-card ${added ? 'tech-card--added' : ''}`}>
      <div className="card-top">
        <div className="tech-icon"><img src={tech.icon} alt="" /></div>
        <span className="badge">{tech.badge}</span>
      </div>
      <h3>{tech.name}</h3>
      <p>{tech.description}</p>
      <div className="meta">
        <span className="chip">{tech.category}</span>
        <span className="difficulty">{tech.difficulty}</span>
      </div>
      <div className="card-bottom">
        <span className="rating">★ <b>{tech.rating}</b></span>
        <button className="add-btn" disabled={added} onClick={() => onAdd(tech)}>
          {added ? '✓ Added to Stack' : '+ Add to Stack'}
        </button>
      </div>
    </article>
  );
}