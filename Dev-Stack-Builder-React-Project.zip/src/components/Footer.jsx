import React from 'react';
import Logo from './Logo';

export default function Footer() {
  return <footer className="footer">
    <div className="container footer-grid">
      <div className="footer-brand"><Logo /><p>A simple space for developers to discover technologies and build better stacks.</p><div className="socials"><a href="https://github.com/" target="_blank" rel="noreferrer">GH</a><a href="https://twitter.com/" target="_blank" rel="noreferrer">𝕏</a><a href="https://linkedin.com/" target="_blank" rel="noreferrer">in</a></div></div>
      <div className="footer-links"><div><b>Product</b><a href="#technologies">Technologies</a><a href="#projects">Projects</a><a href="#home">Features</a></div><div><b>Company</b><a href="#about">About</a><a href="#contact">Contact</a><a href="#home">Careers</a></div><div><b>Legal</b><a href="#home">Privacy</a><a href="#home">Terms</a><a href="#home">Cookies</a></div></div>
    </div>
    <div className="footer-bottom container"><span>© 2026 Dev Stack. Built for developers.</span><div><a href="#home">Privacy</a><a href="#home">Terms</a></div></div>
  </footer>;
}