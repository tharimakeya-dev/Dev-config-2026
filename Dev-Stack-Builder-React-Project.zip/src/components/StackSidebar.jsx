import React from 'react';

export default function StackSidebar({ stack, onRemove, onRemoveAll }) {
  return (
    <aside className="stack-panel">
      <div className="stack-heading">
        <div><span className="stack-icon">▱</span><h2>Your Stack</h2></div>
        <span className="count">{stack.length}</span>
      </div>
      <p className="stack-subtitle">{stack.length} {stack.length === 1 ? 'Technology' : 'Technologies'} Selected</p>
      {stack.length === 0 ? (
        <div className="empty-stack">
          <div className="empty-icon">+</div>
          <h3>Your stack is empty</h3>
          <p>Choose technologies from the list and build your custom development stack.</p>
        </div>
      ) : (
        <div className="stack-list">
          {stack.map(item => (
            <div className="stack-item" key={item.id}>
              <img src={item.icon} alt="" />
              <div><b>{item.name}</b><small>{item.category}</small></div>
              <button aria-label={`Remove ${item.name}`} onClick={() => onRemove(item)}>×</button>
            </div>
          ))}
          <button className="remove-all" onClick={onRemoveAll}>Remove All</button>
        </div>
      )}
      <div className="stack-tip"><span>✦</span><div><b>Pro tip</b><p>A balanced stack usually covers UI, API, data and deployment.</p></div></div>
    </aside>
  );
}