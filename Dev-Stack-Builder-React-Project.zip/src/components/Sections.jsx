import React from 'react';

export function Projects() {
  return <section id="projects" className="section section-muted">
    <div className="container">
      <div className="section-head"><span className="section-kicker">WHAT YOU CAN BUILD</span><h2>Turn your stack into <span>real projects.</span></h2><p>Start with a focused stack and build products that solve real problems.</p></div>
      <div className="project-grid">
        <article className="project-card"><div className="project-art art-one">⌘</div><div><span>FULL STACK</span><h3>Team Workspace</h3><p>Collaborative dashboards, APIs and role-based access.</p></div></article>
        <article className="project-card"><div className="project-art art-two">◈</div><div><span>SAAS</span><h3>Analytics Platform</h3><p>Interactive metrics with a scalable data layer.</p></div></article>
        <article className="project-card"><div className="project-art art-three">⚙</div><div><span>DEVOPS</span><h3>Deploy Pipeline</h3><p>Containerized apps ready for continuous delivery.</p></div></article>
      </div>
    </div>
  </section>;
}

export function About() {
  return <section id="about" className="section">
    <div className="container about-grid">
      <div><span className="section-kicker">WHY DEV STACK</span><h2>Everything you need to <span>choose confidently.</span></h2></div>
      <div className="about-copy"><p>Dev Stack brings popular frontend, backend, database, language, styling, DevOps and developer tools into one simple place.</p><div className="stat-row"><div><b>12+</b><small>Curated technologies</small></div><div><b>7</b><small>Tech categories</small></div><div><b>4.8★</b><small>Average rating</small></div></div></div>
    </div>
  </section>;
}

export function Contact() {
  return <section id="contact" className="section contact-section"><div className="container contact-card"><div><span className="section-kicker">READY TO BUILD?</span><h2>Have a project in mind?</h2><p>Pick your technologies, build your stack and start shipping.</p></div><a href="mailto:hello@devstack.example" className="btn btn-gradient btn-lg">Let's Connect →</a></div></section>;
}