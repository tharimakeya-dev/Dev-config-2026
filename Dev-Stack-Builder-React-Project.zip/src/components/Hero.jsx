import React from 'react';

export default function Hero() {
  return (
    <section id="home" className="hero">
      <div className="container hero-grid">
        <div className="hero-copy">
          <div className="eyebrow"><span className="eyebrow-dot"></span> Build your perfect development stack</div>
          <h1>Build Smarter.<br /><span>Ship Faster.</span></h1>
          <p>Explore modern technologies, compare your options, and create a personalized tech stack for your next big idea.</p>
          <div className="hero-actions">
            <a href="#technologies" className="btn btn-gradient btn-lg">Explore Technologies <span>→</span></a>
            <a href="#about" className="btn btn-outline btn-lg">Learn More</a>
          </div>
          <div className="hero-trust"><span>✦</span> Curated tools for modern developers</div>
        </div>
        <div className="hero-art" aria-hidden="true">
          <div className="code-window">
            <div className="window-top"><span></span><span></span><span></span><b>stack.config</b></div>
            <div className="code-line"><i>01</i><span><em>const</em> stack = {'{'}</span></div>
            <div className="code-line"><i>02</i><span>  frontend: <strong>'React'</strong>,</span></div>
            <div className="code-line"><i>03</i><span>  backend: <strong>'Node.js'</strong>,</span></div>
            <div className="code-line"><i>04</i><span>  database: <strong>'PostgreSQL'</strong>,</span></div>
            <div className="code-line"><i>05</i><span>  deploy: <strong>'Docker'</strong></span></div>
            <div className="code-line"><i>06</i><span>{'}'}</span></div>
            <div className="code-cursor"></div>
          </div>
          <div className="float-card float-card--one"><span>⚡</span><div><b>Fast workflow</b><small>Ready to build</small></div></div>
          <div className="float-card float-card--two"><span>★</span><div><b>4.9 / 5</b><small>Developer rating</small></div></div>
        </div>
      </div>
    </section>
  );
}