import React from 'react';

export default function Logo({ compact = false }) {
  return (
    <a className={`brand ${compact ? 'brand--compact' : ''}`} href="#home" aria-label="Dev Stack home">
      <span className="brand-mark"><span>{'</>'}</span></span>
      {!compact && <span className="brand-name">Dev Stack</span>}
    </a>
  );
}