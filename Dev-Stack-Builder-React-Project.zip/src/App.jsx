import React, { useEffect, useMemo, useState } from 'react';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import TechnologyCard from './components/TechnologyCard';
import StackSidebar from './components/StackSidebar';
import { Projects, About, Contact } from './components/Sections';
import Footer from './components/Footer';

export default function App() {
  const [technologies, setTechnologies] = useState([]);
  const [stack, setStack] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/technologies.json')
      .then(res => {
        if (!res.ok) throw new Error('Unable to load technology data');
        return res.json();
      })
      .then(data => setTechnologies(data))
      .catch(() => toast.error('Could not load technology data.'))
      .finally(() => setLoading(false));
  }, []);

  const stackIds = useMemo(() => new Set(stack.map(item => item.id)), [stack]);

  const addToStack = (tech) => {
    if (stackIds.has(tech.id)) {
      toast.warning(`${tech.name} is already in your stack.`);
      return;
    }
    setStack(prev => [...prev, tech]);
    toast.success(`${tech.name} added to your stack!`);
  };

  const removeFromStack = (tech) => {
    setStack(prev => prev.filter(item => item.id !== tech.id));
    toast.info(`${tech.name} removed from your stack.`);
  };

  const removeAll = () => {
    if (!stack.length) {
      toast.info('Your stack is already empty.');
      return;
    }
    setStack([]);
    toast.info('All technologies removed from your stack.');
  };

  return (
    <>
      <Navbar />
      <main>
        <Hero />
        <section id="technologies" className="section technologies-section">
          <div className="container">
            <div className="section-head section-head--center">
              <span className="section-kicker">EXPLORE THE ECOSYSTEM</span>
              <h2>Choose your <span>technology stack.</span></h2>
              <p>Discover proven tools across every layer of modern web development.</p>
            </div>
            {loading ? (
              <div className="loading"><span className="spinner"></span><b>Loading technologies...</b><p>Fetching your developer toolkit.</p></div>
            ) : (
              <div className="tech-layout">
                <div className="tech-grid">
                  {technologies.map(tech => <TechnologyCard key={tech.id} tech={tech} added={stackIds.has(tech.id)} onAdd={addToStack} />)}
                </div>
                <StackSidebar stack={stack} onRemove={removeFromStack} onRemoveAll={removeAll} />
              </div>
            )}
          </div>
        </section>
        <Projects /><About /><Contact />
      </main>
      <Footer />
      <ToastContainer position="top-right" autoClose={2400} newestOnTop theme="light" />
    </>
  );
}